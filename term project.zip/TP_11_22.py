import random
from tkinter import *
import math

class Gear(object):

    def __init__(self,x,y,r,pradial,pangular,r2):
        self.x=x
        self.y=y
        self.r=r
        self.pradial=pradial
        self.pangular=pangular
        self.px=self.x+self.pradial*math.cos(self.pangular)
        self.py=self.y+self.pradial*math.sin(self.pangular)
        self.r2=r2
        self.fill="gray"   #hardcoded for the moment
    
    def rotate(self):
        self.pangular+=1/360*math.pi
        self.px=self.x+self.pradial*math.cos(self.pangular)
        self.py=self.y+self.pradial*math.sin(self.pangular)
        
    def getAnchor(self):
        return ((self.px, self.py))
        
    def draw(self, canvas):
        canvas.create_oval(self.x-self.r, self.y-self.r, self.x+self.r, 
                        self.y+self.r, fill=self.fill)
        canvas.create_oval(self.px-self.r2, self.py-self.r2, self.px+self.r2, 
                        self.py+self.r2, fill=self.fill) 
            
    def redrawAll(canvas, self):
        draw(canvas, self)
        
class Arm(object):
    
    def __init__(self,startx,starty,endx,endy,lenght):
        self.startx=startx
        self.starty=starty
        self.endx=endx
        self.endy=endy
        
    def getLenght(self):
        return self.lenght
        
    def draw(self, canvas):
        canvas.create_line(self.startx,self.starty,self.endx,self.endy,width=3)

def getAngle(p1, p2):
    p1x,p1y,p2x,p2y=p1[0],p1[1],p2[0],p2[1]
    side1,side2=abs(p1x-p2x),abs(p1y-p2y)
    distance=math.sqrt(side1**2+side2**2)
    angle1=math.pi/2-math.atan(side2/side1) #trigonometry rules apply
    return (angle1)

def init(data):
    data.width=1000
    data.height=600
    data.gear1=Gear(data.width/3,data.height/4,50,40,math.pi*1/4,5)
    data.gear2=Gear(data.width/3*2,data.height/4,40,30,math.pi*3/4,5)
    data.anchor1=data.gear1.getAnchor()
    data.anchor2=data.gear2.getAnchor()
    data.arm1lenght=60    #hardcoded for the moment
    data.endPointInit=(data.width/2,data.height/2)
    data.armAngle=getAngle(data.anchor1, data.endPointInit)+math.pi*2

def timerFired(data):
    data.gear1.rotate()
    data.gear2.rotate()
    data.anchor1x=data.gear1.getAnchor()[0]
    data.anchor1y=data.gear1.getAnchor()[1]
    data.anchor2x=data.gear2.getAnchor()[0]
    data.anchor2y=data.gear2.getAnchor()[1]
    
def draw(canvas, data):    
    data.gear1.draw(canvas)
    data.gear2.draw(canvas)
    
    canvas.create_line(data.anchor1x,data.anchor1y,data.width/2,data.height/2)
    canvas.create_line(data.anchor2x,data.anchor2y,data.width/2,data.height/2)

def redrawAll(canvas, data):
    draw(canvas, data)


####################################
# use the run function as-is
####################################

def run(width=1000, height=600):   #from 112
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 10 # milliseconds
    init(data)
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

####################################
# run call
####################################

run (1000, 600)